package com.example.bus_tracker_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
